function f() {
    "aaaaaaaaaa";
    var o = {
        prop: 1,
        _int: 2,
    };
    return o.prop + o._int;
}
