!function eval() {
}();

!function arguments() {
    "use strict";
}();
