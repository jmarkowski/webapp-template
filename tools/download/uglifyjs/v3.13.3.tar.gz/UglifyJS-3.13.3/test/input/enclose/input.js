function enclose() {
    console.log("test enclose");
}
enclose();
