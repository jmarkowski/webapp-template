var _calls_ = 10, a = 100, b = 10, c = 0;

function f0(b_1, a, undefined_2) {
    a++ + ++b;
    {
        var expr2 = (b + 1 - .1 - .1 - .1 || a || 3).toString();
        L20778: for (var key2 in expr2) {
            (c = c + 1) + [ --b + b_1, typeof f0 == "function" && --_calls_ >= 0 && f0(--b + typeof (undefined_2 = 1 === 1 ? a : b), --b + {
                c: (c = c + 1) + null
            }, a++ + (typeof f0 == "function" && --_calls_ >= 0 && f0(typeof (c = 1 + c, 3 / "a" * ("c" >>> 23..toString()) >= (b_1 && (b_1[(c = c + 1) + a--] = (- -0,
            true + {})))), 3, 25))), 1 === 1 ? a : b ];
        }
    }
}

var a_1 = f0([ , 0 ].length === 2);

console.log(null, a, b, c, Infinity, NaN, undefined);
