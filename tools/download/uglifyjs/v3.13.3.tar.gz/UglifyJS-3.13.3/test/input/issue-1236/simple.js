"use strict";

var foo = function foo(x) {
  return "foo " + x;
};
console.log(foo("bar"));

//# sourceMappingURL=simple.js.map
