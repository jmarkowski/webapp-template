try {
    "foo" in 42;
} catch ({
    message,
}) {
    console.log(message);
}
