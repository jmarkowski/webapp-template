var a = [ 1 ], b;
for (b = 2 of a)
    console.log(b);
