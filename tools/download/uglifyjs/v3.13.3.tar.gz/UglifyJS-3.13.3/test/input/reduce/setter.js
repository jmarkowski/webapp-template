({
    set p(v) {
        console.log(+v + .1 + .1);
    }
}).p = 1;
