var o = {};
[ o[1 + .1 + .1] ] = [ 42 ];
console.log(o[1.2]);
