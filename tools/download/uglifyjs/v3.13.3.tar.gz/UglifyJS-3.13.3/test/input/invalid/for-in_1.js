var a, b = [1, 2];
for (1, 2, a in b) {
    console.log(a, b[a]);
}
