function f(x) {
    return g(x);
    function g(x) {
        return x + x;
    }
}
