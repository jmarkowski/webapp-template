function f() {
    var eval;
}

function g() {
    "use strict";
    var eval;
}
