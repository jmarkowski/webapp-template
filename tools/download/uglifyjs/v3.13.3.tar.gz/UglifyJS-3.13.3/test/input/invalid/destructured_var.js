function f() {
    var { eval } = null;
}

function g() {
    "use strict";
    var { eval } = 42;
}
