var a = [ 1 ];
for (var b = 2 of a)
    console.log(b);
