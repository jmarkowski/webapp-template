console.log(1 || 5--);
