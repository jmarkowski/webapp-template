function arguments() {
}

function eval() {
    "use strict";
}
