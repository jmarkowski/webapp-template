switch (0) {
  default:
  default:
}
